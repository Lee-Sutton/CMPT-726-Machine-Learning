function s = sigmoid(a)
% Compute logistic sigmoid
%
% s = sigmoid(a)
s = 1./(1+exp(-a));